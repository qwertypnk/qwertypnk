// import React from 'react';
// import {RouterConfig} from '../interfaces/ClientInterfaces';
// import NotFoundLayout from '@App/Components/Layouts/NotFoundLayout';
// import GateLayout from '@App/Domains/Gate/GateLayout';
// import UserRegisterLanding from '@App/Domains/Gate/User/Landings/UserRegisterLanding';
// import UserAuthLanding from '@App/Domains/Gate/User/Landings/UserAuthLanding';

// const routes: RouterConfig = {

//   notFound: NotFoundLayout,

//   domains: {

//   Gate: {
//     prefix: 'gate',
//     layout: GateLayout,
//     routes: {
//       'user/register': {
//         component: UserRegisterLanding,
//       },
//       'user/auth': {
//         component: UserAuthLanding,
//       },
//     },
//   },

//   },

// };

// export default routes;