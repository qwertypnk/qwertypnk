import React from 'react';
import {RouterLanding} from 'qwertypnk/client-state/Router';
import {connect} from 'react-redux';

interface ComponentProps {
  //
}
interface StateResponse {
  //
  props: ComponentProps;
}
const Component = connect((state: object, props: ComponentProps) => ({
  //
}))((state: StateResponse) => {
  return <div>Template Home</div>;
});

export default class TemplateHome extends RouterLanding {
  public domain = 'Template';
  public route = '%HomeRouteScheme%';
  public component = Component;
};