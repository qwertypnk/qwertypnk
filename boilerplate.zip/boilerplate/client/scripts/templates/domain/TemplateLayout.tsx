import React, {CSSProperties} from 'react';
import {RouterLayout} from 'qwertypnk/client-state/Router';

const styles: {[key: string]: CSSProperties} = {
  root: {
    padding: 20,
  },
};

const Layout = (props: {children?: React.ReactElement}) => {
  return <div style={styles.root}>
    <h1>Template Layout</h1>

    {props.children}
  </div>;
};

class TemplateLayout extends RouterLayout {
  public domain = 'Template';
  public prefix = '%LayoutPrefix%';
  public layout = Layout;
}

export default TemplateLayout;

export {Layout as TemplateLayout};