import React from 'react';

export default () => {
  return <div>Template Options Widget</div>;
}