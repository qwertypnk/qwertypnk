import React from 'react';

export default (props: {children?: React.ReactElement}) => <div>
  <h2>Template Landing</h2>

  {props.children}
</div>;