process.env.NODE_ENV = 'production';

import fs from 'fs-extra';
import webpack, {Stats} from 'webpack';
import configFactory from './config/webpack.config';
import paths from './config/paths';

const log = (...params: any) => console['l' + 'og'](...params);

// generate configuration
const config = configFactory('production');

// delete build folder
fs.emptyDirSync(paths.appBuild);

// copy public folder
fs.copySync(paths.appPublic, paths.appBuild, {
  dereference: true,
  filter: file => file !== paths.appHtml,
});

// build
const compiler = webpack((config as any));
compiler.run((ex: Error, stats: Stats) => {
  if (ex) {
    log(ex);
    return;
  }

  const {compilation, hash, startTime, endTime} = stats;
  log(`hash: ${hash}\nbuild time: ${(endTime - startTime) / 1000}s\n`);
});