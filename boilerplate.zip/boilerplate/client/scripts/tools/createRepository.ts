import fs from 'fs';

export default (domain: string, repository: string, layoutPrefix: string, homeRouteScheme: string) => {
  if (!fs.existsSync('app')) {
    fs.mkdirSync('app');
  }
  if (!fs.existsSync('Domains')) {
    fs.mkdirSync('Domains');
  }
  if (!fs.existsSync(`app/Domains/${domain}`)) {
    fs.mkdirSync(`app/Domains/${domain}`);
  }

  //

  const repoPath = `app/Domains/${domain}/${repository}`;

  if (!fs.existsSync(repoPath)) {
    fs.mkdirSync(repoPath);
  }

  //

  let file: string;
  let dest: string;

  dest = `app/Domains/${domain}/${domain}Layout.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/domain/TemplateLayout.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    file = file.replace(/Template/g, domain);
    layoutPrefix = layoutPrefix ? `'${layoutPrefix}'` : `null`;
    file = file.replace(/\'\%LayoutPrefix\%\'/g, layoutPrefix);
    fs.writeFileSync(dest, file);
  }

  dest = `app/Domains/${domain}/${domain}Home.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/domain/TemplateHome.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    file = file.replace(/Template/g, domain);
    homeRouteScheme = homeRouteScheme ? `'${homeRouteScheme}'` : `null`;
    file = file.replace(/\'\%HomeRouteScheme\%\'/g, homeRouteScheme);
    fs.writeFileSync(dest, file);
  }

  if (!fs.existsSync(`${repoPath}/Forms`)) {
    fs.mkdirSync(`${repoPath}/Forms`);
  }
  dest = `${repoPath}/Forms/${repository}CreateForm.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateCreateForm.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    fs.writeFileSync(dest, file.replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Landings`)) {
    fs.mkdirSync(`${repoPath}/Landings`);
  }
  dest = `${repoPath}/Landings/${repository}Landing.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateLanding.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    fs.writeFileSync(dest, file.replace(/Template/g, repository));
  }
  dest = `${repoPath}/Landings/${repository}CreateLanding.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateLanding.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    fs.writeFileSync(dest, file.replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Lists`)) {
    fs.mkdirSync(`${repoPath}/Lists`);
  }
  dest = `${repoPath}/Lists/${repository}ListAll.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateListAll.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    fs.writeFileSync(dest, file.replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Views`)) {
    fs.mkdirSync(`${repoPath}/Views`);
  }
  dest = `${repoPath}/Views/${repository}CardView.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateCardView.tsx`, dest);
    file = fs.readFileSync(dest).toString();
    fs.writeFileSync(dest, file.replace(/Template/g, repository));
  }

  //
};