// Do this as the first thing so that any code reading it knows the right env.
process.env.NODE_ENV = 'development';

import fs from 'fs';
import path from 'path';
import webpack from 'webpack';
import WebpackDevServer from 'webpack-dev-server';
import paths from './config/paths';
import configFactory from './config/webpack.config';
import info from '../info.json';

// parseInt(process.env.PORT)
const PORT = info.clientPort;
const HOST = process.env.HOST || '0.0.0.0';

const config = configFactory('development');

const compiler = webpack(config);

const host = process.env.HOST || '0.0.0.0';

const devServer = new WebpackDevServer(compiler, {
  sockHost: info.sockHost,
  sockPort: PORT,
  disableHostCheck: true,
  compress: false,
  contentBase: paths.appPublic,
  watchContentBase: true,
  hot: true,
  publicPath: '/',
  watchOptions: {
    ignored: path.resolve('node_modules'),
    poll: false,
  },
  https: {
    key: fs.readFileSync('../certs/privkey.pem'),
    cert: fs.readFileSync('../certs/fullchain.pem'),
  },
  host,
  overlay: false,
  historyApiFallback: {
    disableDotRule: true,
  },
  public: '0.0.0.0',
});

devServer.listen(PORT, HOST, null);