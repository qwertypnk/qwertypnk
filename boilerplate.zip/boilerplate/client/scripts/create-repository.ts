import createRepository from './tools/createRepository';

const handle = () => {
  const args = process.argv;

  if (!args[2]) {
    console.error('No input.');
    return;
  }

  const split = args[2].split(':');
  if (split.length !== 2) {
    console.error('Invalid repository.');
    return;
  }

  const layoutPrefix = args[3] || null;

  const homeRouteScheme = args[4] || null;

  createRepository(split[0], split[1], layoutPrefix, homeRouteScheme);
};

handle();