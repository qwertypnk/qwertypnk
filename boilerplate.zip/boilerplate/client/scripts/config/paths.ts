import path from 'path';
import fs from 'fs';

// Make sure any symlinks in the project folder are resolved:
// https://github.com/facebook/create-react-app/issues/637
const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = (relativePath: any) => path.resolve(appDirectory, relativePath);

export default {
  appBuild: resolveApp('build'),
  appPublic: resolveApp('../packages/public'),
  appHtml: resolveApp('../packages/public/index.html'),
  appIndex: resolveApp('index.ts'),
  appSrc: resolveApp('app'),
};