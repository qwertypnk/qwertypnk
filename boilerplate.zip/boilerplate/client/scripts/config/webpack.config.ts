import path from 'path';
import webpack, {Configuration} from 'webpack';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import paths from './paths';

export default (webpackEnv: any): Configuration => {
  const isEnvProduction = webpackEnv === 'production';

  return {
    mode: isEnvProduction ? 'production' : 'development',
    devtool: 'source-map',
    entry: paths.appIndex,
    output: {
      path: paths.appBuild,
      publicPath: '/',
    },
    module: {
      rules: [
        {
          test: /\.(tsx|ts|js)$/,
          include: [paths.appSrc, paths.appIndex],
          loader: require.resolve('ts-loader'),
          exclude: [
            /node_modules/,
          ],
        },
      ],
    },
    resolve: {
      extensions: ['.tsx', '.ts', '.js'],
      alias: {
        '@App': path.resolve(__dirname, '../../app/'),
      },
    },
    plugins: [
      // Generates an `index.html` file with the <script> injected.
      new HtmlWebpackPlugin({
        inject: true,
        template: paths.appHtml,
        isEnvProduction,
        // minify: isEnvProduction
        //   ? {
        //     removeComments: false,
        //     collapseWhitespace: false,
        //     removeRedundantAttributes: false,
        //     useShortDoctype: false,
        //     removeEmptyAttributes: false,
        //     removeStyleLinkTypeAttributes: false,
        //     keepClosingSlash: true,
        //     minifyJS: false,
        //     minifyCSS: false,
        //     minifyURLs: false,
        //   }
        //   : {
        //     //
        //   },
        minify: {
          // no minify
        },
      }),
      new webpack.DefinePlugin({
        '__REACT_DEVTOOLS_GLOBAL_HOOK__': '({ isDisabled: true })',
      }),
    ],
  };
};
