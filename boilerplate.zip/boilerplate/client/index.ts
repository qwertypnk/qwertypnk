import Init from '@App/Vendor/Init';
import info from './info.json';
import {AuthRecord} from '../interfaces/RecordInterfaces';
import LoadingSeedLayout from '@App/Components/Layouts/LoadingSeedLayout';
import SeedFailedLayout from '@App/Components/Layouts/SeedFailedLayout';
import ClientStorage from 'qwertypnk/client-state/ClientStorage';
import InputValidator from '@App/InputValidator';
import routes from '@App/routes';

Init({
  loadingComponent: LoadingSeedLayout,
  failedComponent: SeedFailedLayout,
  storage: ClientStorage,
  apiUrl: info.apiUrl,
  authorization: (authRecord: AuthRecord) => {
    if (!authRecord) {
      return null;
    }
    return btoa(JSON.stringify({
      repository: authRecord.repository,
      uuid: authRecord.uuid,
      createdAt: authRecord.createdAt,
      token: authRecord.token,
    }));
  },
  defaultDomain: 'v0.9.0',
  routerConfig: routes,
  validator: new InputValidator(),
});