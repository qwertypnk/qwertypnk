require('module-alias/register');
import {AuthActiveState} from '@App/vendor/State/RecordHandler';
import {AuthRecord, RecordEntry} from 'qwertypnk/interfaces/RecordInterfaces';
import Init from '@App/vendor/Tools/Init';
import Jwt from 'jwt-simple';
import info from './info.json';

process.env.TZ = 'utc';

const logger = (...params: any) => console['l' + 'og'](...params); // one may be cmd+shit+f-ing ". l og (" a lot

const activeState: AuthActiveState = async (record: RecordEntry): Promise<boolean> => {
    return false;
};

Init({
    auth: {
        token: async (authorization: string): Promise<AuthRecord> => {
            try {
                if (!authorization) {
                    return null;
                }
                // todo here: real implementation (validate info with db or similar strategy)
                const buffer = JSON.parse(Buffer.from(authorization, 'base64').toString());
                const secret = [buffer.repository, buffer.uuid, buffer.createdAt, 'secret'];
                const jwt = Jwt.decode(buffer.token, secret.join(':'));
                if (!jwt) {
                    return null;
                }
                return {
                    repository: buffer.repository,
                    uuid: buffer.uuid,
                    createdAt: buffer.createdAt,
                    active: await activeState(null), // todo here: fetch record and place it as param in active state getter
                    token: buffer.token,
                };
            } catch (ex) {
                console.warn(ex);
                return null;
            }
        },
        activeState,
        createToken: async (record: RecordEntry): Promise<string> => {
            // todo here: real implementation (add password / salt / etc to secret)
            // const secret = [record['id'] || 'ok', record.repository, record.uuid, record.createdAt, record['password'] || 'ok', 'secret'];
            const secret = [record.repository, record.uuid, record.createdAt, 'secret'];
            return Jwt.encode({
                repository: record.repository,
                uuid: record.uuid,
                createdAt: record.createdAt,
            }, secret.join(':'));
        },
    },
    logger,
    port: info.apiPort,
});