declare module 'hapi-cors';
