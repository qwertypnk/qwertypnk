// import { execSync } from 'child_process';
// import fs from 'fs';
// import path from 'path';

// const files = fs.readdirSync(path.resolve('../packages'));
// files.map((file: any) => {
//   if (file === 'qwertypnk' || file === 'public' || file === '.git' || !fs.lstatSync(path.resolve('../packages', file)).isDirectory()) {
//     return;
//   }
//   execSync(`npm install --save "../packages/${file}"`);
// });

// execSync('npm install --save "../packages/qwertypnk"');