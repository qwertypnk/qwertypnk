import fs from 'fs';

export default (domain: string, repository: string) => {
  if (!fs.existsSync('app')) {
    fs.mkdirSync('app');
  }
  if (!fs.existsSync('Domains')) {
    fs.mkdirSync('Domains');
  }
  if (!fs.existsSync(`app/Domains/${domain}`)) {
    fs.mkdirSync(`app/Domains/${domain}`);
  }

  //

  const repoPath = `app/Domains/${domain}/${repository}`;

  if (!fs.existsSync(repoPath)) {
    fs.mkdirSync(repoPath);
  }

  //

  let file: Buffer;
  let dest: string;

  dest = `app/Domains/${domain}/${domain}Layout.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateLayout.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, domain));
  }

  if (!fs.existsSync(`${repoPath}/Forms`)) {
    fs.mkdirSync(`${repoPath}/Forms`);
  }
  dest = `${repoPath}/Forms/${repository}CreateForm.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateCreateForm.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Landings`)) {
    fs.mkdirSync(`${repoPath}/Landings`);
  }
  dest = `${repoPath}/Landings/${repository}Landing.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateLanding.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, repository));
  }
  dest = `${repoPath}/Landings/${repository}CreateLanding.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateLanding.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Lists`)) {
    fs.mkdirSync(`${repoPath}/Lists`);
  }
  dest = `${repoPath}/Lists/${repository}FullLoad.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateFullLoad.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, repository));
  }

  if (!fs.existsSync(`${repoPath}/Views`)) {
    fs.mkdirSync(`${repoPath}/Views`);
  }
  dest = `${repoPath}/Views/${repository}CardView.tsx`;
  if (!fs.existsSync(dest)) {
    fs.copyFileSync(`scripts/templates/repository/TemplateCardView.tsx`, dest);
    file = fs.readFileSync(dest);
    fs.writeFileSync(dest, file.toString().replace(/Template/g, repository));
  }

  //
};