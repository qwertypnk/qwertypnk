import React from 'react';

export default () => {
  return <div>
    Template List All
  </div>;
};