import React from 'react';

export default (props: {children?: any}) => <div>
  <h2>Template Landing</h2>

  {props.children}
</div>;