import React from 'react';
import TemplateCreateForm from './TemplateCreateForm';

export default (props: {children?: any}) => <div>
  <h2>Template Create Landing</h2>

  <TemplateCreateForm/>
</div>;