import React from 'react';

export default (props: {children?: any}) => <div>
  <h1>Template Layout</h1>

  {props.children}
</div>;