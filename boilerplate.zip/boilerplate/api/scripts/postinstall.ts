import fs from 'fs';
import { execSync } from 'child_process';

// symlinks
const symlinks = ['proxy', 'public', 'certs', 'devnotes.txt', 'info.json'];
symlinks.map(symlink => {
  if (!fs.existsSync(`./${symlink}`)) {
    fs.symlinkSync(`../${symlink}`, `./${symlink}`);
  }
});

// symlink to qwertypnk package source
if (!fs.existsSync('./qwertypnk-src')) {
  fs.symlinkSync('../packages/qwertypnk', './qwertypnk-src');
}

// package install procedure
execSync('npx ts-node scripts/install-packages.ts');