process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

require('module-alias/register');
import fs from 'fs';
import path from 'path';
import Hapi, { Request, ResponseToolkit, RouteOptionsPayload } from '@hapi/hapi';
import HapiInert from '@hapi/inert';
import https, { RequestOptions } from 'https';
import info from '@root/info.json';
import FormData from 'form-data';
import nodeFetch from 'node-fetch';

// redo the interfaces and helper functions so that proxy does not have anny package dependencies
// (no nodemon reload for packages)

interface Exception {
  name: string;
  message: string;
  stack: string;
  send: { error: string };
}

interface ProxyUrlToPortMap {
  default: {
    host: string;
    port: number;
    headers: { [key: string]: string };
  };
  set?: {
    [key: string]: {
      host: string;
      port: number;
      headers: { [key: string]: string };
    };
  };
}

const getException = (ex: any): Exception => {
  const name = ex.name || 'Error';
  const message = ex.message || 'unknown error';
  const description = `${name}: ${message}`;
  return {
    name,
    message,
    stack: ex.stack || description,
    send: { error: description },
  };
};

const publicDir = path.resolve('./public');

try {
  (async (): Promise<void> => {
    process.env.TZ = 'utc';

    const proxyUrlToPortMap: ProxyUrlToPortMap = {
      default: {
        host: info.devClientDomain,
        port: info.devClientPort,
        headers: {},
      },
      set: {
        api: {
          host: info.devApiDomain,
          port: info.devApiPort,
          headers: {},
        },
      },
    };

    const server = Hapi.server({
      port: 443,
      host: '0.0.0.0',
      tls: {
        key: fs.readFileSync(path.resolve('./certs/privkey.pem')),
        cert: fs.readFileSync(path.resolve('./certs/fullchain.pem')),
        // rejectUnauthorized: false,
      },
      routes: {
        files: {
          relativeTo: publicDir,
        },
      },
    });

    const payloadOptions: RouteOptionsPayload = {
      maxBytes: 1024 * 1024 * 10,
      parse: true,
      allow: [
        'application/json',
        'multipart/form-data',
        'image/jpeg',
        'application/pdf',
        'application/x-www-form-urlencoded',
      ],
      multipart: {
        output: 'file',
      },
      output: 'file',
    };

    await server.register(HapiInert);

    server.route({
      method: ['POST', 'PUT', 'PATCH'],
      path: '/{any*}',
      options: {
        payload: payloadOptions,
      },
      handler: async (request: Request, handler: ResponseToolkit) => {
        // if file
        const file = request.url.pathname.substr(1);
        if (file && fs.existsSync(path.resolve(publicDir, file))) {
          return handler.file(file);
        }

        const set = proxyUrlToPortMap.set || {};
        for (let [url, proxy] of Object.entries(set)) {
          url = url.replace(/^(.+?)\/*?$/, '$1');
          url = url.charAt(0) === '/' ? url : `/${url}`;
          let pathname = request.url.pathname;
          if (pathname.substr(0, url.length) === pathname.substr(0, url.length + 1)) {
            pathname = `${pathname}/`;
          }
          pathname === '//' && (pathname = '/');
          if (pathname.substr(0, url.length + 1) !== `${url}/`) {
            continue;
          }

          // todo here: v2 - also handle files

          const form = new FormData();
          Object.entries(request.payload || {}).map(([key, value]) => {
            form.append(key, value);
          });

          const nextUrl =
            request.url.protocol + '//' + proxy.host + ':' + proxy.port + request.url.pathname.substr(url.length);

          try {
            return await (
              await nodeFetch(nextUrl, {
                method: request.method,
                body: form,
                headers: {
                  //   ...request.headers,
                  //   ...proxy.headers,
                  ...form.getHeaders(),
                },
              })
            ).json();
          } catch (ex) {
            ex = getException(ex);
            // console.warn(ex.stack);
            return ex.send;
          }
        }

        return null;
      },
    });

    server.route({
      method: ['OPTIONS', 'GET', 'DELETE'],
      path: '/{any*}',
      handler: async (request: Request, handler: ResponseToolkit) => {
        // if file
        const file = request.url.pathname.substr(1);
        if (file && fs.existsSync(path.resolve(publicDir, file))) {
          return handler.file(file);
        }

        const set = proxyUrlToPortMap.set || {};
        for (let [url, proxy] of Object.entries(set)) {
          url = url.replace(/^(.+?)\/*?$/, '$1');
          url = url.charAt(0) === '/' ? url : `/${url}`;
          let pathname = request.url.pathname;
          if (pathname.substr(0, url.length) === pathname.substr(0, url.length + 1)) {
            pathname = `${pathname}/`;
          }
          pathname === '//' && (pathname = '/');
          if (pathname.substr(0, url.length + 1) !== `${url}/`) {
            continue;
          }

          // todo here: v2 - replace with node-fetch
          return new Promise((resolve) => {
            const options: RequestOptions = {
              rejectUnauthorized: false,
              protocol: request.url.protocol,
              host: proxy.host,
              port: proxy.port,
              path: `${request.url.pathname.substr(url.length)}`,
              method: request.method,
              headers: {
                ...request.headers,
                ...proxy.headers,
              },
            };
            const req = https.request(options, (res) => {
              let data = '';
              res.on('end', () => resolve(data));
              res.on('error', (err) => {
                const ex = getException(err);
                console.warn(ex.stack);
                resolve(ex.send);
              });
              res.on('data', (chunk) => (data += chunk));
            });
            req.end();
            req.on('error', (err) => {
              const ex = getException(err);
              console.warn(ex.stack);
              resolve(ex.send);
            });
          }).catch((ex) => {
            ex = getException(ex);
            console.warn(ex.stack);
            return ex.send;
          });
        }

        return new Promise((resolve) => {
          const options: RequestOptions = {
            protocol: request.url.protocol,
            host: proxyUrlToPortMap.default.host,
            port: proxyUrlToPortMap.default.port,
            path: request.url.pathname,
            method: request.method,
            headers: {
              ...request.headers,
              ...proxyUrlToPortMap.default.headers,
            },
          };
          const req = https.request(options, (res) => {
            let data = '';
            res.on('end', () => resolve(data));
            res.on('error', (err) => {
              const ex = getException(err);
              console.warn(ex.stack);
              resolve(ex.send);
            });
            res.on('data', (chunk) => (data += chunk));
          });
          req.end();
          req.on('error', (err) => {
            const ex = getException(err);
            console.warn(ex.stack);
            resolve(ex.send);
          });
        }).catch((ex) => {
          ex = getException(ex);
          // console.warn(ex.stack);
          return ex.send;
        });
      },
    });

    await server.start();
    console.info(`Server running on ${server.info.uri}`);
  })();
} catch (ex) {
  ex = getException(ex);
  console.warn(ex.stack);
}
