const { execSync } = require('child_process');
const TscWatchClient = require('tsc-watch/client');

const watch = new TscWatchClient();

try {
  execSync('npx tsc', { stdio: 'inherit' });

  watch.on('success', () => {
    // do something
  });

  watch.start();
} catch (ex) {
  console.error(ex);
}
